interface AbstractEntity<ID = unknown> {
}
export default AbstractEntity;
