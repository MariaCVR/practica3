interface Expresion {
    id?: number;
    expresion?: string;
    isCorrecto?: boolean;
}
export default Expresion;
