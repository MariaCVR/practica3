interface Artista {
    id?: number;
    nombres?: string;
    nacionidad?: string;
}
export default Artista;
