import { EndpointRequestInit as EndpointRequestInit_1 } from "@vaadin/hilla-frontend";
import client_1 from "./connect-client.default.js";
async function create_1(idArtista: number | undefined, idBanda: number | undefined, rol: string | undefined, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("ArtistaBandaServices", "create", { idArtista, idBanda, rol }, init); }
async function listAll_1(init?: EndpointRequestInit_1): Promise<Array<Record<string, string | undefined> | undefined> | undefined> { return client_1.call("ArtistaBandaServices", "listAll", {}, init); }
async function update_1(id: number | undefined, idArtista: number | undefined, idBanda: number | undefined, rol: string | undefined, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("ArtistaBandaServices", "update", { id, idArtista, idBanda, rol }, init); }
export { create_1 as create, listAll_1 as listAll, update_1 as update };
