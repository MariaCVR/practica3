import { ViewConfig } from '@vaadin/hilla-file-router/types.js';
import { useSignal } from '@vaadin/hilla-react-signals';
import { Button } from '@vaadin/react-components/Button.js';
import { ComboBox } from '@vaadin/react-components/ComboBox.js';
import { TextField } from '@vaadin/react-components/TextField.js';
import { Grid } from '@vaadin/react-components/Grid.js';
import { GridColumn } from '@vaadin/react-components/GridColumn.js';
import { Notification } from '@vaadin/react-components/Notification.js';

import { VerticalLayout } from '@vaadin/react-components/VerticalLayout.js';
import { HorizontalLayout } from '@vaadin/react-components/HorizontalLayout.js';
import { PracticaServices } from 'Frontend/generated/endpoints.js';
import { useEffect } from 'react';

export const config: ViewConfig = {
  menu: { order: 6, icon: 'line-awesome/svg/chart-line-solid.svg' },
  title: 'Práctica de Algoritmos',
};

interface TiempoMedicion {
  algoritmo: string;
  criterio: string;
  tiempo1: number;
  tiempo2: number;
  tiempo3: number;
  tiempoPromedio: number;
}

interface ResultadoBusqueda {
  encontrado: boolean;
  metodoUsado: string;
  tiempoBusqueda: number;
  posicion: number;
  elemento?: any;
  error?: string;
}

interface DatoMusical {
  id: number;
  nombre?: string;
  nombres?: string;
  duracion?: number;
  url?: string;
  tipo?: string;
  nacionalidad?: string;
  fecha?: string;
}

export default function PracticaView() {
  // Señales para el estado
  const tipoObjeto = useSignal('cancion');
  const criterioOrdenacion = useSignal('nombre');
  const algoritmo = useSignal('quicksort');
  const criteriBusqueda = useSignal('nombre');
  const valorBusqueda = useSignal('');
  
  // Datos
  const datos = useSignal<any[]>([]);
  const tiempos = useSignal<any[]>([]);
  const resultadoBusqueda = useSignal<any>(null);
  const estadisticas = useSignal<any>({});
  const resultadosMultiples = useSignal<any[]>([]);

  // Opciones para los combos
  const tiposObjeto = [
    { label: 'Canciones', value: 'cancion' },
    { label: 'Artistas', value: 'artista' },
    { label: 'Bandas', value: 'banda' }
  ];

  const algoritmos = [
    { label: 'Quicksort', value: 'quicksort' },
    { label: 'Shellsort', value: 'shellsort' }
  ];

  const criteriosCancion = [
    { label: 'Nombre', value: 'nombre' },
    { label: 'Duración', value: 'duracion' },
    { label: 'ID', value: 'id' }
  ];

  const criteriosArtista = [
    { label: 'Nombre', value: 'nombre' },
    { label: 'Nacionalidad', value: 'nacionalidad' },
    { label: 'ID', value: 'id' }
  ];

  const criteriosBanda = [
    { label: 'Nombre', value: 'nombre' },
    { label: 'Fecha', value: 'fecha' },
    { label: 'ID', value: 'id' }
  ];

  const getCriterios = () => {
    switch (tipoObjeto.value) {
      case 'artista': return criteriosArtista;
      case 'banda': return criteriosBanda;
      default: return criteriosCancion;
    }
  };

  // Cargar datos iniciales
  useEffect(() => {
    cargarDatos();
    cargarEstadisticas();
  }, []);

  const cargarDatos = async () => {
    try {
      const resultado = await PracticaServices.obtenerDatosOrdenados(
        tipoObjeto.value, 
        'ninguno', 
        'nombre'
      );
      datos.value = resultado || [];
    } catch (error) {
      Notification.show('Error al cargar datos', { theme: 'error' });
    }
  };

  const cargarEstadisticas = async () => {
    try {
      const stats = await PracticaServices.obtenerEstadisticas();
      estadisticas.value = stats || {};
    } catch (error) {
      console.error('Error al cargar estadísticas:', error);
    }
  };

  const medirTiempos = async () => {
    try {
      Notification.show('Midiendo tiempos de ordenación...', { theme: 'primary' });
      const resultado = await PracticaServices.medirTiemposOrdenacion(
        tipoObjeto.value, 
        criterioOrdenacion.value
      );
      tiempos.value = resultado || [];
      Notification.show('Medición completada', { theme: 'success' });
    } catch (error) {
      Notification.show('Error al medir tiempos', { theme: 'error' });
    }
  };

  const ordenarDatos = async () => {
    try {
      const resultado = await PracticaServices.obtenerDatosOrdenados(
        tipoObjeto.value, 
        algoritmo.value, 
        criterioOrdenacion.value
      );
      datos.value = resultado || [];
      Notification.show(`Datos ordenados con ${algoritmo.value}`, { theme: 'success' });
    } catch (error) {
      Notification.show('Error al ordenar datos', { theme: 'error' });
    }
  };

  const buscarElemento = async () => {
    if (!valorBusqueda.value.trim()) {
      Notification.show('Ingrese un valor para buscar', { theme: 'error' });
      return;
    }

    try {
      const resultado = await PracticaServices.buscarElemento(
        tipoObjeto.value, 
        criteriBusqueda.value, 
        valorBusqueda.value
      );
      if (resultado) {
        resultadoBusqueda.value = resultado;
        
        if (resultado.encontrado) {
          Notification.show(
            `Encontrado con ${resultado.metodoUsado} en ${resultado.tiempoBusqueda}ms`, 
            { theme: 'success' }
          );
        } else {
          Notification.show('No se encontraron resultados', { theme: 'contrast' });
        }
      }
    } catch (error) {
      Notification.show('Error en la búsqueda', { theme: 'error' });
    }
  };

  const buscarMultiples = async () => {
    if (!valorBusqueda.value.trim()) {
      Notification.show('Ingrese un valor para buscar', { theme: 'error' });
      return;
    }

    try {
      const resultado = await PracticaServices.buscarElementosMultiples(
        tipoObjeto.value, 
        criteriBusqueda.value, 
        valorBusqueda.value
      );
      if (resultado) {
        resultadosMultiples.value = resultado;
        Notification.show(`Se encontraron ${resultado.length} resultados`, { theme: 'success' });
      }
    } catch (error) {
      Notification.show('Error en la búsqueda múltiple', { theme: 'error' });
    }
  };

  const generarDatos = async () => {
    try {
      Notification.show('Generando datos adicionales...', { theme: 'primary' });
      await PracticaServices.generarDatosAdicionales(1000);
      await cargarDatos();
      await cargarEstadisticas();
      Notification.show('1000 datos adicionales generados', { theme: 'success' });
    } catch (error) {
      Notification.show('Error al generar datos', { theme: 'error' });
    }
  };



  return (
    <VerticalLayout style={{ height: '100%', padding: '20px' }}>
      <h1 style={{ textAlign: 'center', color: '#1976d2' }}>
        📊 Práctica de Algoritmos de Ordenación y Búsqueda
      </h1>
      
      {/* Sección de Ordenación */}
      <div style={{ width: '100%', padding: '20px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '20px' }}>
        <h2>Primera Parte: Métodos de Ordenación</h2>
        
        <HorizontalLayout style={{ alignItems: 'end', gap: '20px', flexWrap: 'wrap' }}>
          <ComboBox
            label="Tipo de Objeto"
            items={tiposObjeto}
            value={tipoObjeto.value}
            onValueChanged={(e: any) => {
              tipoObjeto.value = e.detail.value;
              cargarDatos();
            }}
            style={{ minWidth: '200px' }}
          />
          <ComboBox
            label="Criterio de Ordenación"
            items={getCriterios()}
            value={criterioOrdenacion.value}
            onValueChanged={(e: any) => criterioOrdenacion.value = e.detail.value}
            style={{ minWidth: '200px' }}
          />
          <ComboBox
            label="Algoritmo"
            items={algoritmos}
            value={algoritmo.value}
            onValueChanged={(e: any) => algoritmo.value = e.detail.value}
            style={{ minWidth: '200px' }}
          />
        </HorizontalLayout>
        
        <HorizontalLayout style={{ gap: '20px', marginTop: '20px' }}>
          <Button theme="primary" onClick={medirTiempos}>
            Medir Tiempos (3 veces)
          </Button>
          <Button theme="secondary" onClick={ordenarDatos}>
            Ordenar Datos
          </Button>
          <Button onClick={generarDatos}>
            Generar 1000 Datos Adicionales
          </Button>
        </HorizontalLayout>
      </div>

      {/* Resultados de Tiempo */}
      {tiempos.value.length > 0 && (
        <div style={{ width: '100%', padding: '20px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '20px' }}>
          <h3>Resultados de Medición de Tiempos</h3>
          <Grid items={tiempos.value} style={{ width: '100%' }}>
            <GridColumn path="algoritmo" header="Algoritmo" />
            <GridColumn path="criterio" header="Criterio" />
            <GridColumn path="tiempo1" header="Tiempo 1 (ms)" />
            <GridColumn path="tiempo2" header="Tiempo 2 (ms)" />
            <GridColumn path="tiempo3" header="Tiempo 3 (ms)" />
            <GridColumn path="tiempoPromedio" header="Promedio (ms)" />
          </Grid>
        </div>
      )}

      {/* Sección de Búsqueda */}
      <div style={{ width: '100%', padding: '20px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '20px' }}>
        <h2>Segunda Parte: Métodos de Búsqueda</h2>
        
        <HorizontalLayout style={{ alignItems: 'end', gap: '20px', flexWrap: 'wrap' }}>
          <ComboBox
            label="Tipo de Objeto"
            items={tiposObjeto}
            value={tipoObjeto.value}
            onValueChanged={(e: any) => tipoObjeto.value = e.detail.value}
            style={{ minWidth: '200px' }}
          />
          <ComboBox
            label="Criterio de Búsqueda"
            items={getCriterios()}
            value={criteriBusqueda.value}
            onValueChanged={(e: any) => criteriBusqueda.value = e.detail.value}
            style={{ minWidth: '200px' }}
          />
          <TextField
            label="Valor a Buscar"
            value={valorBusqueda.value}
            onValueChanged={(e: any) => valorBusqueda.value = e.detail.value}
            style={{ minWidth: '250px' }}
            placeholder="Ingrese el valor a buscar..."
          />
        </HorizontalLayout>
        
        <HorizontalLayout style={{ gap: '20px', marginTop: '20px' }}>
          <Button theme="primary" onClick={buscarElemento}>
            Búsqueda Inteligente
          </Button>
          <Button theme="secondary" onClick={buscarMultiples}>
            Búsqueda Múltiple
          </Button>
        </HorizontalLayout>
      </div>

      {/* Resultado de Búsqueda Individual */}
      {resultadoBusqueda.value && (
        <div style={{ width: '100%', padding: '20px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '20px' }}>
          <h3>Resultado de Búsqueda Individual</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px' }}>
            <div>
              <strong>Estado:</strong> {resultadoBusqueda.value.encontrado ? '✅ Encontrado' : '❌ No encontrado'}
            </div>
            <div>
              <strong>Método:</strong> {resultadoBusqueda.value.metodoUsado}
            </div>
            <div>
              <strong>Tiempo:</strong> {resultadoBusqueda.value.tiempoBusqueda} ms
            </div>
            <div>
              <strong>Posición:</strong> {resultadoBusqueda.value.posicion >= 0 ? resultadoBusqueda.value.posicion : 'N/A'}
            </div>
          </div>
          
          {resultadoBusqueda.value.elemento && (
            <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
              <h4>Elemento Encontrado:</h4>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px' }}>
                {Object.entries(resultadoBusqueda.value.elemento).map(([key, value]) => (
                  <div key={key}>
                    <strong>{key}:</strong> {String(value)}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Resultados de Búsqueda Múltiple */}
      {resultadosMultiples.value.length > 0 && (
        <div style={{ width: '100%', padding: '20px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '20px' }}>
          <h3>Resultados de Búsqueda Múltiple ({resultadosMultiples.value.length} encontrados)</h3>
          <Grid items={resultadosMultiples.value} style={{ width: '100%', height: '400px' }}>
            <GridColumn path="id" header="ID" width="80px" />
            {tipoObjeto.value === 'cancion' && (
              <>
                <GridColumn path="nombre" header="Nombre" />
                <GridColumn path="duracion" header="Duración (seg)" width="150px" />
                <GridColumn path="tipo" header="Tipo" width="100px" />
              </>
            )}
            {tipoObjeto.value === 'artista' && (
              <>
                <GridColumn path="nombres" header="Nombres" />
                <GridColumn path="nacionidad" header="Nacionalidad" />
              </>
            )}
            {tipoObjeto.value === 'banda' && (
              <>
                <GridColumn path="nombre" header="Nombre" />
                <GridColumn path="fecha" header="Fecha" />
              </>
            )}
          </Grid>
        </div>
      )}

      {/* Datos Ordenados */}
      <div style={{ width: '100%', padding: '20px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '20px' }}>
        <h3>Datos Ordenados</h3>
        <Grid items={datos.value} style={{ width: '100%', height: '400px' }}>
          <GridColumn path="id" header="ID" width="80px" />
          {tipoObjeto.value === 'cancion' && (
            <>
              <GridColumn path="nombre" header="Nombre" />
              <GridColumn path="duracion" header="Duración (seg)" width="150px" />
              <GridColumn path="tipo" header="Tipo" width="100px" />
            </>
          )}
          {tipoObjeto.value === 'artista' && (
            <>
              <GridColumn path="nombres" header="Nombres" />
              <GridColumn path="nacionidad" header="Nacionalidad" />
            </>
          )}
          {tipoObjeto.value === 'banda' && (
            <>
              <GridColumn path="nombre" header="Nombre" />
              <GridColumn path="fecha" header="Fecha" />
            </>
          )}
        </Grid>
      </div>

      {/* Estadísticas */}
      <div style={{ width: '100%', padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h2>Estadísticas del Sistema</h2>
        
        <HorizontalLayout style={{ gap: '20px', flexWrap: 'wrap' }}>
          <div style={{ padding: '20px', minWidth: '200px', textAlign: 'center', border: '1px solid #ddd', borderRadius: '8px' }}>
            <h1 style={{ color: '#1976d2', margin: '0' }}>
              {estadisticas.value.totalCanciones || 0}
            </h1>
            <h3 style={{ margin: '10px 0 0 0' }}>Canciones</h3>
          </div>
          
          <div style={{ padding: '20px', minWidth: '200px', textAlign: 'center', border: '1px solid #ddd', borderRadius: '8px' }}>
            <h1 style={{ color: '#388e3c', margin: '0' }}>
              {estadisticas.value.totalArtistas || 0}
            </h1>
            <h3 style={{ margin: '10px 0 0 0' }}>Artistas</h3>
          </div>
          
          <div style={{ padding: '20px', minWidth: '200px', textAlign: 'center', border: '1px solid #ddd', borderRadius: '8px' }}>
            <h1 style={{ color: '#d32f2f', margin: '0' }}>
              {estadisticas.value.totalBandas || 0}
            </h1>
            <h3 style={{ margin: '10px 0 0 0' }}>Bandas</h3>
          </div>
        </HorizontalLayout>
        
        <div style={{ marginTop: '20px' }}>
          <Button 
            theme="primary" 
            onClick={cargarEstadisticas}
            style={{ marginTop: '20px' }}
          >
            Actualizar Estadísticas
          </Button>
        </div>
      </div>
    </VerticalLayout>
  );
} 