import { ViewConfig } from '@vaadin/hilla-file-router/types.js';
import { Button, ComboBox, Dialog, Grid, GridColumn, GridItemModel, VerticalLayout, Select } from '@vaadin/react-components';
import { Notification } from '@vaadin/react-components/Notification';

import { useSignal } from '@vaadin/hilla-react-signals';
import handleError from 'Frontend/views/_ErrorHandler';
import { Group, ViewToolbar } from 'Frontend/components/ViewToolbar';

import { useDataProvider } from '@vaadin/hilla-react-crud';
import { ArtistaBandaServices, ArtistaService, BandaService } from 'Frontend/generated/endpoints';

export const config: ViewConfig = {
  title: 'Artista Banda',
  menu: {
    icon: 'vaadin:clipboard-check',
    order: 3,
    title: 'Artista Banda',
  },
};

type ArtistaBandaEntryFormProps = {
  onArtistaBandaCreated?: () => void;
};

function ArtistaBandaEntryForm(props: ArtistaBandaEntryFormProps) {
  const dialogOpened = useSignal(false);
  const artistaId = useSignal<number | null>(null);
  const bandaId = useSignal<number | null>(null);
  const rol = useSignal('');
  const artistas = useSignal<Array<{ label: string; value: string }>>([]);
  const bandas = useSignal<Array<{ label: string; value: string }>>([]);
  const roles = [
    { label: 'Solista', value: 'SOLISTA' },
    { label: 'Vocalista', value: 'VOCALISTA' },
    { label: 'Baterista', value: 'BATERISTA' },
    { label: 'Bajista', value: 'BAJISTA' },
    { label: 'Guitarrista', value: 'GUITARRISTA' }
  ];

  const open = async () => {
    dialogOpened.value = true;
    const artistasList = await ArtistaService.listAll();
    const bandasList = await BandaService.listAllBanda();
    artistas.value = artistasList?.filter((a): a is NonNullable<typeof a> => a != null)
      .map(a => ({ label: a.nombres || '', value: a.id?.toString() || '' })) || [];
    bandas.value = bandasList?.filter((b): b is NonNullable<typeof b> => b != null)
      .map(b => ({ label: b.nombre || '', value: b.id?.toString() || '' })) || [];
  };

  const close = () => {
    dialogOpened.value = false;
    artistaId.value = null;
    bandaId.value = null;
    rol.value = '';
  };

  const createArtistaBanda = async () => {
    try {
      if (artistaId.value && bandaId.value && rol.value.trim().length > 0) {
        await ArtistaBandaServices.create(artistaId.value, bandaId.value, rol.value);
        if (props.onArtistaBandaCreated) {
          props.onArtistaBandaCreated();
        }
        close();
        Notification.show('Relación artista-banda creada exitosamente', { duration: 5000, position: 'bottom-end', theme: 'success' });
      } else {
        Notification.show('No se pudo crear, faltan datos', { duration: 5000, position: 'top-center', theme: 'error' });
      }
    } catch (error) {
      console.log(error);
      handleError(error);
    }
  };

  return (
    <>
      <Dialog
        aria-label="Registrar Artista-Banda"
        draggable
        modeless
        opened={dialogOpened.value}
        onOpenedChanged={(event) => {
          dialogOpened.value = event.detail.value;
        }}
        header={
          <h2
            className="draggable"
            style={{
              flex: 1,
              cursor: 'move',
              margin: 0,
              fontSize: '1.5em',
              fontWeight: 'bold',
              padding: 'var(--lumo-space-m) 0',
            }}
          >
            Registrar Artista-Banda
          </h2>
        }
        footerRenderer={() => (
          <>
            <Button onClick={close}>Cancelar</Button>
            <Button theme="primary" onClick={createArtistaBanda}>
              Registrar
            </Button>
          </>
        )}
      >
        <VerticalLayout
          theme="spacing"
          style={{ width: '300px', maxWidth: '100%', alignItems: 'stretch' }}
        >
          <VerticalLayout style={{ alignItems: 'stretch' }}>
            <ComboBox
              label="Artista"
              items={artistas.value}
              value={artistaId.value?.toString()}
              allowCustomValue={false}
              onValueChanged={(evt) => {
                const value = evt.detail.value;
                if (value) {
                  const selectedItem = artistas.value.find(item => item.value === value);
                  if (selectedItem) {
                    artistaId.value = parseInt(selectedItem.value);
                  }
                } else {
                  artistaId.value = null;
                }
              }}
            />
            <ComboBox
              label="Banda"
              items={bandas.value}
              value={bandaId.value?.toString()}
              allowCustomValue={false}
              onValueChanged={(evt) => {
                const value = evt.detail.value;
                if (value) {
                  const selectedItem = bandas.value.find(item => item.value === value);
                  if (selectedItem) {
                    bandaId.value = parseInt(selectedItem.value);
                  }
                } else {
                  bandaId.value = null;
                }
              }}
            />
            <ComboBox
              label="Rol"
              items={roles}
              value={rol.value}
              allowCustomValue={false}
              onValueChanged={(evt) => {
                rol.value = evt.detail.value || '';
              }}
            />
          </VerticalLayout>
        </VerticalLayout>
      </Dialog>
      <Button onClick={open}>Registrar</Button>
    </>
  );
}

type ArtistaBandaEntryFormUpdateProps = {
  artistaBanda: any;
  onArtistaBandaUpdated?: () => void;
};

function ArtistaBandaEntryFormUpdate(props: ArtistaBandaEntryFormUpdateProps) {
  const dialogOpened = useSignal(false);
  const artistaId = useSignal<number | null>(null);
  const bandaId = useSignal<number | null>(null);
  const rol = useSignal('');
  const artistas = useSignal<Array<{ label: string; value: string }>>([]);
  const bandas = useSignal<Array<{ label: string; value: string }>>([]);
  const roles = [
    { label: 'Solista', value: 'SOLISTA' },
    { label: 'Vocalista', value: 'VOCALISTA' },
    { label: 'Baterista', value: 'BATERISTA' },
    { label: 'Bajista', value: 'BAJISTA' },
    { label: 'Guitarrista', value: 'GUITARRISTA' }
  ];

  const open = async () => {
    dialogOpened.value = true;
    artistaId.value = props.artistaBanda.id_artista;
    bandaId.value = props.artistaBanda.id_banda;
    rol.value = props.artistaBanda.rol;
    const artistasList = await ArtistaService.listAll();
    const bandasList = await BandaService.listAllBanda();
    artistas.value = artistasList?.filter((a): a is NonNullable<typeof a> => a != null)
      .map(a => ({ label: a.nombres || '', value: a.id?.toString() || '' })) || [];
    bandas.value = bandasList?.filter((b): b is NonNullable<typeof b> => b != null)
      .map(b => ({ label: b.nombre || '', value: b.id?.toString() || '' })) || [];
  };

  const close = () => {
    dialogOpened.value = false;
  };

  const updateArtistaBanda = async () => {
    try {
      if (artistaId.value && bandaId.value && rol.value.trim().length > 0) {
        await ArtistaBandaServices.update(
          props.artistaBanda.id,
          artistaId.value,
          bandaId.value,
          rol.value
        );
        if (props.onArtistaBandaUpdated) {
          props.onArtistaBandaUpdated();
        }
        close();
        Notification.show('Relación artista-banda actualizada exitosamente', { duration: 5000, position: 'bottom-end', theme: 'success' });
      } else {
        Notification.show('No se pudo actualizar, faltan datos', { duration: 5000, position: 'top-center', theme: 'error' });
      }
    } catch (error) {
      console.log(error);
      handleError(error);
    }
  };

  return (
    <>
      <Dialog
        aria-label="Editar Artista-Banda"
        draggable
        modeless
        opened={dialogOpened.value}
        onOpenedChanged={(event) => {
          dialogOpened.value = event.detail.value;
        }}
        header={
          <h2
            className="draggable"
            style={{
              flex: 1,
              cursor: 'move',
              margin: 0,
              fontSize: '1.5em',
              fontWeight: 'bold',
              padding: 'var(--lumo-space-m) 0',
            }}
          >
            Editar Artista-Banda
          </h2>
        }
        footerRenderer={() => (
          <>
            <Button onClick={close}>Cancelar</Button>
            <Button theme="primary" onClick={updateArtistaBanda}>
              Actualizar
            </Button>
          </>
        )}
      >
        <VerticalLayout
          theme="spacing"
          style={{ width: '300px', maxWidth: '100%', alignItems: 'stretch' }}
        >
          <VerticalLayout style={{ alignItems: 'stretch' }}>
            <Select
              label="Artista"
              items={artistas.value}
              value={artistaId.value?.toString()}
              onValueChanged={(evt) => {
                const value = evt.detail.value;
                artistaId.value = value ? parseInt(value) : null;
              }}
            />
            <Select
              label="Banda"
              items={bandas.value}
              value={bandaId.value?.toString()}
              onValueChanged={(evt) => {
                const value = evt.detail.value;
                bandaId.value = value ? parseInt(value) : null;
              }}
            />
            <Select
              label="Rol"
              items={roles}
              value={rol.value}
              onValueChanged={(evt) => {
                rol.value = evt.detail.value || '';
              }}
            />
          </VerticalLayout>
        </VerticalLayout>
      </Dialog>
      <Button onClick={open}>Editar</Button>
    </>
  );
}

function index({ model }: { model: GridItemModel<any> }) {
  return (
    <span>
      {model.index + 1}
    </span>
  );
}

function link({ item }: { item: any }) {
  return (
    <span>
      <ArtistaBandaEntryFormUpdate artistaBanda={item} onArtistaBandaUpdated={() => window.location.reload()} />
    </span>
  );
}

export default function ArtistaBandaListView() {
  const dataProvider = useDataProvider({
    list: async () => {
      const result = await ArtistaBandaServices.listAll();
      return result || [];
    },
  });

  return (
    <main className="w-full h-full flex flex-col box-border gap-s p-m">
      <ViewToolbar title="Artistas-Bandas">
        <Group>
          <ArtistaBandaEntryForm onArtistaBandaCreated={dataProvider.refresh} />
        </Group>
      </ViewToolbar>
      <Grid dataProvider={dataProvider.dataProvider}>
        <GridColumn header="Nro" renderer={index} />
        <GridColumn path="artista" header="Artista"/>
        <GridColumn path="banda" header="Banda"/> 
        <GridColumn path="rol" header="Rol"/>
        <GridColumn header="Acciones" renderer={link} />
      </Grid>
    </main>
  );
}
