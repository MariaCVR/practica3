package org.unl.music.base.controller.dao.dao_models;

import org.unl.music.base.models.Cancion;

import org.unl.music.base.controller.dao.AdapterDao;

import java.util.LinkedList;

public class DaoCancion extends AdapterDao<Cancion> {
    private Cancion obj;

    public DaoCancion() {
        super(Cancion.class);
        // TODO Auto-generated constructor stub
    }

    public Cancion getObj() {
        if (obj == null)
            this.obj = new Cancion();
        return this.obj;
    }

    public void setObj(Cancion obj) {
        this.obj = obj;
    }

    public Boolean save() {
        try {
            obj.setId(listAll().getLength() + 1);
            this.persist(obj);
            return true;
        } catch (Exception e) {
            // TODO
            return false;
            // TODO: handle exception
        }
    }

    public Boolean update(Integer pos) {
        try {
            this.update(obj, pos);
            return true;
        } catch (Exception e) {
            // TODO
            return false;
            // TODO: handle exception
        }
    }

    public Cancion getById(Integer id) {
        try {
            org.unl.music.base.controller.data_struct.list.LinkedList<Cancion> list = listAll();
            for (int i = 0; i < list.getLength(); i++) {
                Cancion cancion = list.get(i);
                if (cancion.getId().equals(id)) {
                    return cancion;
                }
            }
            return null;
        } catch (Exception e) {
            System.err.println("Error getting cancion by id: " + e.getMessage());
            return null;
        }
    }

    public Boolean update(Cancion cancion) {
        try {
            super.update(cancion, cancion.getId());
            return true;
        } catch (Exception e) {
            System.err.println("Error updating cancion: " + e.getMessage());
            return false;
        }
    }

}
