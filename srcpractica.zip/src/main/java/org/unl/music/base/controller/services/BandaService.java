package org.unl.music.base.controller.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.text.SimpleDateFormat;

import org.unl.music.base.controller.dao.dao_models.DaoArtista;
import org.unl.music.base.controller.dao.dao_models.DaoBanda;
import org.unl.music.base.models.Artista_Banda;
import org.unl.music.base.models.Banda;

import com.github.javaparser.quality.NotNull;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import com.vaadin.hilla.BrowserCallable;

import io.micrometer.common.lang.NonNull;
import jakarta.validation.constraints.NotEmpty;

@BrowserCallable
@AnonymousAllowed
public class BandaService {
    private DaoBanda db;

    public BandaService() {
        db = new DaoBanda();
    }

    public void createBanda(@NotEmpty String nombre, @NotEmpty String fechaStr) throws Exception {
        if (nombre.trim().length() > 0 && fechaStr.trim().length() > 0) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date fecha = sdf.parse(fechaStr);

            db.getObj().setNombre(nombre);
            db.getObj().setFecha(fecha);
            if (!db.save())
                throw new Exception("No se pudo guardar los datos de la banda");
        }
    }

    public void updateBanda(Integer id, @NotEmpty String nombre, @NotEmpty String fechaStr) throws Exception {
        if (id != null && id > 0 && nombre.trim().length() > 0 && fechaStr.trim().length() > 0) {
            Banda banda = db.getById(id);
            if (banda == null) {
                throw new Exception("No se encontró la banda con ID: " + id);
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date fecha = sdf.parse(fechaStr);

            banda.setNombre(nombre);
            banda.setFecha(fecha);

            if (!db.update(banda))
                throw new Exception("No se pudo modificar los datos de la banda");
        }
    }

    public List<Banda> listAllBanda() {
        return Arrays.asList(db.listAll().toArray());
    }

    public List<HashMap> listBanda() {
        List<HashMap> lista = new ArrayList<>();
        if (!db.listAll().isEmpty()) {
            Banda[] arreglo = db.listAll().toArray();

            for (int i = 0; i < arreglo.length; i++) {

                HashMap<String, String> aux = new HashMap<>();
                aux.put("id", arreglo[i].getId().toString(i));
                aux.put("nombre", arreglo[i].getNombre());
                lista.add(aux);
            }
        }
        return lista;
    }
}
