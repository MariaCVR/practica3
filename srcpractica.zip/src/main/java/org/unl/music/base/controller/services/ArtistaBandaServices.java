package org.unl.music.base.controller.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.unl.music.base.controller.data_struct.list.LinkedList;

import org.unl.music.base.controller.dao.dao_models.DaoArtista;
import org.unl.music.base.controller.dao.dao_models.DaoArtistaBanda;
import org.unl.music.base.controller.dao.dao_models.DaoBanda;
import org.unl.music.base.models.Artista_Banda;
import org.unl.music.base.models.Banda;
import org.unl.music.base.models.Artista;
import org.unl.music.base.models.RolArtistaEnum;

import com.vaadin.flow.server.auth.AnonymousAllowed;
import com.vaadin.hilla.BrowserCallable;

@BrowserCallable
@AnonymousAllowed
public class ArtistaBandaServices {
    private DaoArtistaBanda db;
    private DaoArtista da;
    private DaoBanda dbBanda;

    public ArtistaBandaServices() {
        db = new DaoArtistaBanda();
        da = new DaoArtista();
        dbBanda = new DaoBanda();
    }

    public List<Map<String, String>> listAll() {
        List<Map<String, String>> result = new ArrayList<>();
        LinkedList<Artista_Banda> artistasBandas = db.listAll();
        if (artistasBandas != null && !artistasBandas.isEmpty()) {
            Artista_Banda[] arreglo = artistasBandas.toArray();
            for (Artista_Banda ab : arreglo) {
                Map<String, String> map = new HashMap<>();
                map.put("id", ab.getId().toString());
                map.put("id_artista", ab.getId_artista().toString());
                map.put("id_banda", ab.getId_banda().toString());
                map.put("rol", ab.getRol().toString());

                // Buscar artista por ID
                Artista artista = da.getById(ab.getId_artista());
                if (artista != null) {
                    map.put("artista", artista.getNombres());
                } else {
                    map.put("artista", "Artista no encontrado");
                }

                // Buscar banda por ID
                Banda banda = dbBanda.getById(ab.getId_banda());
                if (banda != null) {
                    map.put("banda", banda.getNombre());
                } else {
                    map.put("banda", "Banda no encontrada");
                }

                result.add(map);
            }
        }
        return result;
    }

    public void create(Integer idArtista, Integer idBanda, String rol) throws Exception {
        if (idArtista == null || idBanda == null || rol == null || rol.trim().isEmpty()) {
            throw new Exception("Todos los campos son obligatorios");
        }

        if (idArtista <= 0 || idBanda <= 0) {
            throw new Exception("IDs inválidos");
        }

        // Verificar que el artista y la banda existan
        Artista artista = da.getById(idArtista);
        Banda banda = dbBanda.getById(idBanda);

        if (artista == null || banda == null) {
            throw new Exception("Artista o banda no encontrados");
        }

        Artista_Banda artistaBanda = new Artista_Banda();
        artistaBanda.setId_artista(idArtista);
        artistaBanda.setId_banda(idBanda);
        artistaBanda.setRol(RolArtistaEnum.valueOf(rol));

        db.setObj(artistaBanda);
        db.save();
    }

    public void update(Integer id, Integer idArtista, Integer idBanda, String rol) throws Exception {
        if (id == null || idArtista == null || idBanda == null || rol == null || rol.trim().isEmpty()) {
            throw new Exception("Todos los campos son obligatorios");
        }

        if (id <= 0 || idArtista <= 0 || idBanda <= 0) {
            throw new Exception("IDs inválidos");
        }

        // Verificar que el artista y la banda existan
        Artista artista = da.getById(idArtista);
        Banda banda = dbBanda.getById(idBanda);

        if (artista == null || banda == null) {
            throw new Exception("Artista o banda no encontrados");
        }

        Artista_Banda artistaBanda = db.getById(id);
        if (artistaBanda == null) {
            throw new Exception("No se encontró la relación artista-banda");
        }

        artistaBanda.setId_artista(idArtista);
        artistaBanda.setId_banda(idBanda);
        artistaBanda.setRol(RolArtistaEnum.valueOf(rol));

        db.update(artistaBanda, id);
    }
}
