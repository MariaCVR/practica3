package org.unl.music.base.controller.algoritmos;

import org.unl.music.base.controller.data_struct.list.LinkedList;
import org.unl.music.base.models.Cancion;
import org.unl.music.base.models.Artista;
import org.unl.music.base.models.Banda;

public class AlgoritmosOrdenacion {

    // Clase para almacenar resultados de medición
    public static class ResultadoOrdenacion {
        private long tiempo1, tiempo2, tiempo3;
        private double tiempoPromedio;
        private String algoritmo;
        private String criterio;

        public ResultadoOrdenacion(String algoritmo, String criterio) {
            this.algoritmo = algoritmo;
            this.criterio = criterio;
        }

        public void setTiempos(long t1, long t2, long t3) {
            this.tiempo1 = t1;
            this.tiempo2 = t2;
            this.tiempo3 = t3;
            this.tiempoPromedio = (t1 + t2 + t3) / 3.0;
        }

        // Getters
        public long getTiempo1() {
            return tiempo1;
        }

        public long getTiempo2() {
            return tiempo2;
        }

        public long getTiempo3() {
            return tiempo3;
        }

        public double getTiempoPromedio() {
            return tiempoPromedio;
        }

        public String getAlgoritmo() {
            return algoritmo;
        }

        public String getCriterio() {
            return criterio;
        }
    }

    // ==============================================
    // QUICKSORT PARA CANCIONES
    // ==============================================

    public static LinkedList<Cancion> quicksortCanciones(LinkedList<Cancion> lista, String criterio) {
        if (lista.isEmpty())
            return lista;

        Cancion[] array = lista.toArray();
        quicksortCancionesArray(array, 0, array.length - 1, criterio);
        lista.toList(array);
        return lista;
    }

    private static void quicksortCancionesArray(Cancion[] array, int inicio, int fin, String criterio) {
        if (inicio < fin) {
            int pivotIndex = particionCanciones(array, inicio, fin, criterio);
            quicksortCancionesArray(array, inicio, pivotIndex - 1, criterio);
            quicksortCancionesArray(array, pivotIndex + 1, fin, criterio);
        }
    }

    private static int particionCanciones(Cancion[] array, int inicio, int fin, String criterio) {
        Cancion pivot = array[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (compararCanciones(array[j], pivot, criterio) <= 0) {
                i++;
                intercambiarCanciones(array, i, j);
            }
        }
        intercambiarCanciones(array, i + 1, fin);
        return i + 1;
    }

    // ==============================================
    // SHELLSORT PARA CANCIONES
    // ==============================================

    public static LinkedList<Cancion> shellsortCanciones(LinkedList<Cancion> lista, String criterio) {
        if (lista.isEmpty())
            return lista;

        Cancion[] array = lista.toArray();
        int n = array.length;

        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; i++) {
                Cancion temp = array[i];
                int j = i;
                while (j >= gap && compararCanciones(array[j - gap], temp, criterio) > 0) {
                    array[j] = array[j - gap];
                    j -= gap;
                }
                array[j] = temp;
            }
        }

        lista.toList(array);
        return lista;
    }

    // ==============================================
    // QUICKSORT PARA ARTISTAS
    // ==============================================

    public static LinkedList<Artista> quicksortArtistas(LinkedList<Artista> lista, String criterio) {
        if (lista.isEmpty())
            return lista;

        Artista[] array = lista.toArray();
        quicksortArtistasArray(array, 0, array.length - 1, criterio);
        lista.toList(array);
        return lista;
    }

    private static void quicksortArtistasArray(Artista[] array, int inicio, int fin, String criterio) {
        if (inicio < fin) {
            int pivotIndex = particionArtistas(array, inicio, fin, criterio);
            quicksortArtistasArray(array, inicio, pivotIndex - 1, criterio);
            quicksortArtistasArray(array, pivotIndex + 1, fin, criterio);
        }
    }

    private static int particionArtistas(Artista[] array, int inicio, int fin, String criterio) {
        Artista pivot = array[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (compararArtistas(array[j], pivot, criterio) <= 0) {
                i++;
                intercambiarArtistas(array, i, j);
            }
        }
        intercambiarArtistas(array, i + 1, fin);
        return i + 1;
    }

    // ==============================================
    // SHELLSORT PARA ARTISTAS
    // ==============================================

    public static LinkedList<Artista> shellsortArtistas(LinkedList<Artista> lista, String criterio) {
        if (lista.isEmpty())
            return lista;

        Artista[] array = lista.toArray();
        int n = array.length;

        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; i++) {
                Artista temp = array[i];
                int j = i;
                while (j >= gap && compararArtistas(array[j - gap], temp, criterio) > 0) {
                    array[j] = array[j - gap];
                    j -= gap;
                }
                array[j] = temp;
            }
        }

        lista.toList(array);
        return lista;
    }

    // ==============================================
    // QUICKSORT PARA BANDAS
    // ==============================================

    public static LinkedList<Banda> quicksortBandas(LinkedList<Banda> lista, String criterio) {
        if (lista.isEmpty())
            return lista;

        Banda[] array = lista.toArray();
        quicksortBandasArray(array, 0, array.length - 1, criterio);
        lista.toList(array);
        return lista;
    }

    private static void quicksortBandasArray(Banda[] array, int inicio, int fin, String criterio) {
        if (inicio < fin) {
            int pivotIndex = particionBandas(array, inicio, fin, criterio);
            quicksortBandasArray(array, inicio, pivotIndex - 1, criterio);
            quicksortBandasArray(array, pivotIndex + 1, fin, criterio);
        }
    }

    private static int particionBandas(Banda[] array, int inicio, int fin, String criterio) {
        Banda pivot = array[fin];
        int i = inicio - 1;

        for (int j = inicio; j < fin; j++) {
            if (compararBandas(array[j], pivot, criterio) <= 0) {
                i++;
                intercambiarBandas(array, i, j);
            }
        }
        intercambiarBandas(array, i + 1, fin);
        return i + 1;
    }

    // ==============================================
    // SHELLSORT PARA BANDAS
    // ==============================================

    public static LinkedList<Banda> shellsortBandas(LinkedList<Banda> lista, String criterio) {
        if (lista.isEmpty())
            return lista;

        Banda[] array = lista.toArray();
        int n = array.length;

        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; i++) {
                Banda temp = array[i];
                int j = i;
                while (j >= gap && compararBandas(array[j - gap], temp, criterio) > 0) {
                    array[j] = array[j - gap];
                    j -= gap;
                }
                array[j] = temp;
            }
        }

        lista.toList(array);
        return lista;
    }

    // ==============================================
    // MÉTODOS DE COMPARACIÓN
    // ==============================================

    private static int compararCanciones(Cancion c1, Cancion c2, String criterio) {
        switch (criterio.toLowerCase()) {
            case "nombre":
                return c1.getNombre().compareToIgnoreCase(c2.getNombre());
            case "duracion":
                return c1.getDuracion().compareTo(c2.getDuracion());
            case "id":
                return c1.getId().compareTo(c2.getId());
            default:
                return c1.getNombre().compareToIgnoreCase(c2.getNombre());
        }
    }

    private static int compararArtistas(Artista a1, Artista a2, String criterio) {
        switch (criterio.toLowerCase()) {
            case "nombre":
                return a1.getNombres().compareToIgnoreCase(a2.getNombres());
            case "nacionalidad":
                return a1.getNacionidad().compareToIgnoreCase(a2.getNacionidad());
            case "id":
                return a1.getId().compareTo(a2.getId());
            default:
                return a1.getNombres().compareToIgnoreCase(a2.getNombres());
        }
    }

    private static int compararBandas(Banda b1, Banda b2, String criterio) {
        switch (criterio.toLowerCase()) {
            case "nombre":
                return b1.getNombre().compareToIgnoreCase(b2.getNombre());
            case "fecha":
                return b1.getFecha().compareTo(b2.getFecha());
            case "id":
                return b1.getId().compareTo(b2.getId());
            default:
                return b1.getNombre().compareToIgnoreCase(b2.getNombre());
        }
    }

    // ==============================================
    // MÉTODOS DE INTERCAMBIO
    // ==============================================

    private static void intercambiarCanciones(Cancion[] array, int i, int j) {
        Cancion temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    private static void intercambiarArtistas(Artista[] array, int i, int j) {
        Artista temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    private static void intercambiarBandas(Banda[] array, int i, int j) {
        Banda temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    // ==============================================
    // MÉTODOS PARA MEDIR TIEMPOS
    // ==============================================

    public static ResultadoOrdenacion medirTiemposQuicksortCanciones(LinkedList<Cancion> lista, String criterio) {
        ResultadoOrdenacion resultado = new ResultadoOrdenacion("Quicksort", criterio);

        // Primera medición
        LinkedList<Cancion> copia1 = copiarListaCanciones(lista);
        long tiempo1 = System.currentTimeMillis();
        quicksortCanciones(copia1, criterio);
        tiempo1 = System.currentTimeMillis() - tiempo1;

        // Segunda medición
        LinkedList<Cancion> copia2 = copiarListaCanciones(lista);
        long tiempo2 = System.currentTimeMillis();
        quicksortCanciones(copia2, criterio);
        tiempo2 = System.currentTimeMillis() - tiempo2;

        // Tercera medición
        LinkedList<Cancion> copia3 = copiarListaCanciones(lista);
        long tiempo3 = System.currentTimeMillis();
        quicksortCanciones(copia3, criterio);
        tiempo3 = System.currentTimeMillis() - tiempo3;

        resultado.setTiempos(tiempo1, tiempo2, tiempo3);
        return resultado;
    }

    public static ResultadoOrdenacion medirTiemposShellsortCanciones(LinkedList<Cancion> lista, String criterio) {
        ResultadoOrdenacion resultado = new ResultadoOrdenacion("Shellsort", criterio);

        // Primera medición
        LinkedList<Cancion> copia1 = copiarListaCanciones(lista);
        long tiempo1 = System.currentTimeMillis();
        shellsortCanciones(copia1, criterio);
        tiempo1 = System.currentTimeMillis() - tiempo1;

        // Segunda medición
        LinkedList<Cancion> copia2 = copiarListaCanciones(lista);
        long tiempo2 = System.currentTimeMillis();
        shellsortCanciones(copia2, criterio);
        tiempo2 = System.currentTimeMillis() - tiempo2;

        // Tercera medición
        LinkedList<Cancion> copia3 = copiarListaCanciones(lista);
        long tiempo3 = System.currentTimeMillis();
        shellsortCanciones(copia3, criterio);
        tiempo3 = System.currentTimeMillis() - tiempo3;

        resultado.setTiempos(tiempo1, tiempo2, tiempo3);
        return resultado;
    }

    // ==============================================
    // MÉTODOS AUXILIARES
    // ==============================================

    private static LinkedList<Cancion> copiarListaCanciones(LinkedList<Cancion> original) {
        LinkedList<Cancion> copia = new LinkedList<>();
        if (!original.isEmpty()) {
            Cancion[] array = original.toArray();
            for (Cancion cancion : array) {
                copia.add(cancion);
            }
        }
        return copia;
    }
}