package org.unl.music.base.controller.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.unl.music.base.service.PracticaService;
import org.unl.music.base.controller.algoritmos.AlgoritmosOrdenacion;
import org.unl.music.base.controller.algoritmos.AlgoritmosBusqueda;
import org.unl.music.base.controller.data_struct.list.LinkedList;
import org.unl.music.base.models.Cancion;
import org.unl.music.base.models.Artista;
import org.unl.music.base.models.Banda;

import com.vaadin.flow.server.auth.AnonymousAllowed;
import com.vaadin.hilla.BrowserCallable;

@BrowserCallable
@AnonymousAllowed
public class PracticaServices {

    @Autowired
    private PracticaService practicaService;

    public PracticaServices() {
        this.practicaService = new PracticaService();
    }

    // ==============================================
    // ENDPOINTS PARA ORDENACIÓN
    // ==============================================

    public List<HashMap<String, Object>> medirTiemposOrdenacion(String tipoObjeto, String criterio) {
        List<HashMap<String, Object>> resultados = new ArrayList<>();

        try {
            AlgoritmosOrdenacion.ResultadoOrdenacion resultadoQuick = null;
            AlgoritmosOrdenacion.ResultadoOrdenacion resultadoShell = null;

            if ("cancion".equalsIgnoreCase(tipoObjeto)) {
                resultadoQuick = practicaService.ordenarCancionesQuicksort(criterio);
                resultadoShell = practicaService.ordenarCancionesShellsort(criterio);
            }

            if (resultadoQuick != null) {
                HashMap<String, Object> quickResult = new HashMap<>();
                quickResult.put("algoritmo", resultadoQuick.getAlgoritmo());
                quickResult.put("criterio", resultadoQuick.getCriterio());
                quickResult.put("tiempo1", resultadoQuick.getTiempo1());
                quickResult.put("tiempo2", resultadoQuick.getTiempo2());
                quickResult.put("tiempo3", resultadoQuick.getTiempo3());
                quickResult.put("tiempoPromedio", resultadoQuick.getTiempoPromedio());
                resultados.add(quickResult);
            }

            if (resultadoShell != null) {
                HashMap<String, Object> shellResult = new HashMap<>();
                shellResult.put("algoritmo", resultadoShell.getAlgoritmo());
                shellResult.put("criterio", resultadoShell.getCriterio());
                shellResult.put("tiempo1", resultadoShell.getTiempo1());
                shellResult.put("tiempo2", resultadoShell.getTiempo2());
                shellResult.put("tiempo3", resultadoShell.getTiempo3());
                shellResult.put("tiempoPromedio", resultadoShell.getTiempoPromedio());
                resultados.add(shellResult);
            }

        } catch (Exception e) {
            System.err.println("Error en medición de tiempos: " + e.getMessage());
        }

        return resultados;
    }

    public List<HashMap<String, Object>> obtenerDatosOrdenados(String tipoObjeto, String algoritmo, String criterio) {
        List<HashMap<String, Object>> lista = new ArrayList<>();

        try {
            if ("cancion".equalsIgnoreCase(tipoObjeto)) {
                LinkedList<Cancion> canciones = practicaService.obtenerCancionesOrdenadas(algoritmo, criterio);
                if (!canciones.isEmpty()) {
                    Cancion[] arreglo = canciones.toArray();
                    for (int i = 0; i < arreglo.length; i++) {
                        HashMap<String, Object> aux = new HashMap<>();
                        aux.put("id", arreglo[i].getId());
                        aux.put("nombre", arreglo[i].getNombre());
                        aux.put("duracion", arreglo[i].getDuracion());
                        aux.put("url", arreglo[i].getUrl() != null ? arreglo[i].getUrl() : "");
                        aux.put("tipo", arreglo[i].getTipo() != null ? arreglo[i].getTipo().toString() : "MP3");
                        aux.put("id_genero", arreglo[i].getId_genero());
                        aux.put("id_album", arreglo[i].getId_album());
                        lista.add(aux);
                    }
                }
            } else if ("artista".equalsIgnoreCase(tipoObjeto)) {
                LinkedList<Artista> artistas = practicaService.obtenerArtistasOrdenados(algoritmo, criterio);
                if (!artistas.isEmpty()) {
                    Artista[] arreglo = artistas.toArray();
                    for (int i = 0; i < arreglo.length; i++) {
                        HashMap<String, Object> aux = new HashMap<>();
                        aux.put("id", arreglo[i].getId());
                        aux.put("nombres", arreglo[i].getNombres());
                        aux.put("nacionidad", arreglo[i].getNacionidad());
                        lista.add(aux);
                    }
                }
            } else if ("banda".equalsIgnoreCase(tipoObjeto)) {
                LinkedList<Banda> bandas = practicaService.obtenerBandasOrdenadas(algoritmo, criterio);
                if (!bandas.isEmpty()) {
                    Banda[] arreglo = bandas.toArray();
                    for (int i = 0; i < arreglo.length; i++) {
                        HashMap<String, Object> aux = new HashMap<>();
                        aux.put("id", arreglo[i].getId());
                        aux.put("nombre", arreglo[i].getNombre());
                        aux.put("fecha", arreglo[i].getFecha().toString());
                        lista.add(aux);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error al obtener datos ordenados: " + e.getMessage());
        }

        return lista;
    }

    // ==============================================
    // ENDPOINTS PARA BÚSQUEDA
    // ==============================================

    public HashMap<String, Object> buscarElemento(String tipoObjeto, String criterio, String valor) {
        HashMap<String, Object> resultado = new HashMap<>();

        try {
            if ("cancion".equalsIgnoreCase(tipoObjeto)) {
                AlgoritmosBusqueda.ResultadoBusqueda<Cancion> busqueda = practicaService.buscarCancion(criterio, valor);
                resultado.put("encontrado", busqueda.isEncontrado());
                resultado.put("metodoUsado", busqueda.getMetodoUsado());
                resultado.put("tiempoBusqueda", busqueda.getTiempoBusqueda());
                resultado.put("posicion", busqueda.getPosicion());

                if (busqueda.isEncontrado() && busqueda.getElemento() != null) {
                    Cancion cancion = busqueda.getElemento();
                    HashMap<String, Object> elemento = new HashMap<>();
                    elemento.put("id", cancion.getId());
                    elemento.put("nombre", cancion.getNombre());
                    elemento.put("duracion", cancion.getDuracion());
                    elemento.put("url", cancion.getUrl());
                    elemento.put("tipo", cancion.getTipo() != null ? cancion.getTipo().toString() : "MP3");
                    resultado.put("elemento", elemento);
                }
            } else if ("artista".equalsIgnoreCase(tipoObjeto)) {
                AlgoritmosBusqueda.ResultadoBusqueda<Artista> busqueda = practicaService.buscarArtista(criterio, valor);
                resultado.put("encontrado", busqueda.isEncontrado());
                resultado.put("metodoUsado", busqueda.getMetodoUsado());
                resultado.put("tiempoBusqueda", busqueda.getTiempoBusqueda());
                resultado.put("posicion", busqueda.getPosicion());

                if (busqueda.isEncontrado() && busqueda.getElemento() != null) {
                    Artista artista = busqueda.getElemento();
                    HashMap<String, Object> elemento = new HashMap<>();
                    elemento.put("id", artista.getId());
                    elemento.put("nombres", artista.getNombres());
                    elemento.put("nacionidad", artista.getNacionidad());
                    resultado.put("elemento", elemento);
                }
            } else if ("banda".equalsIgnoreCase(tipoObjeto)) {
                AlgoritmosBusqueda.ResultadoBusqueda<Banda> busqueda = practicaService.buscarBanda(criterio, valor);
                resultado.put("encontrado", busqueda.isEncontrado());
                resultado.put("metodoUsado", busqueda.getMetodoUsado());
                resultado.put("tiempoBusqueda", busqueda.getTiempoBusqueda());
                resultado.put("posicion", busqueda.getPosicion());

                if (busqueda.isEncontrado() && busqueda.getElemento() != null) {
                    Banda banda = busqueda.getElemento();
                    HashMap<String, Object> elemento = new HashMap<>();
                    elemento.put("id", banda.getId());
                    elemento.put("nombre", banda.getNombre());
                    elemento.put("fecha", banda.getFecha().toString());
                    resultado.put("elemento", elemento);
                }
            }
        } catch (Exception e) {
            resultado.put("error", "Error en búsqueda: " + e.getMessage());
        }

        return resultado;
    }

    public List<HashMap<String, Object>> buscarElementosMultiples(String tipoObjeto, String criterio, String valor) {
        List<HashMap<String, Object>> resultados = new ArrayList<>();

        try {
            if ("cancion".equalsIgnoreCase(tipoObjeto)) {
                LinkedList<Cancion> canciones = practicaService.buscarCancionesMultiples(criterio, valor);
                if (!canciones.isEmpty()) {
                    Cancion[] arreglo = canciones.toArray();
                    for (int i = 0; i < arreglo.length; i++) {
                        HashMap<String, Object> aux = new HashMap<>();
                        aux.put("id", arreglo[i].getId());
                        aux.put("nombre", arreglo[i].getNombre());
                        aux.put("duracion", arreglo[i].getDuracion());
                        aux.put("url", arreglo[i].getUrl());
                        aux.put("tipo", arreglo[i].getTipo() != null ? arreglo[i].getTipo().toString() : "MP3");
                        resultados.add(aux);
                    }
                }
            } else if ("artista".equalsIgnoreCase(tipoObjeto)) {
                LinkedList<Artista> artistas = practicaService.buscarArtistasMultiples(criterio, valor);
                if (!artistas.isEmpty()) {
                    Artista[] arreglo = artistas.toArray();
                    for (int i = 0; i < arreglo.length; i++) {
                        HashMap<String, Object> aux = new HashMap<>();
                        aux.put("id", arreglo[i].getId());
                        aux.put("nombres", arreglo[i].getNombres());
                        aux.put("nacionidad", arreglo[i].getNacionidad());
                        resultados.add(aux);
                    }
                }
            } else if ("banda".equalsIgnoreCase(tipoObjeto)) {
                LinkedList<Banda> bandas = practicaService.buscarBandasMultiples(criterio, valor);
                if (!bandas.isEmpty()) {
                    Banda[] arreglo = bandas.toArray();
                    for (int i = 0; i < arreglo.length; i++) {
                        HashMap<String, Object> aux = new HashMap<>();
                        aux.put("id", arreglo[i].getId());
                        aux.put("nombre", arreglo[i].getNombre());
                        aux.put("fecha", arreglo[i].getFecha().toString());
                        resultados.add(aux);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error en búsqueda múltiple: " + e.getMessage());
        }

        return resultados;
    }

    // ==============================================
    // ENDPOINTS PARA CRUD
    // ==============================================

    public boolean actualizarCancion(Integer id, String nombre, Integer duracion, String url) {
        try {
            Cancion cancion = new Cancion();
            cancion.setId(id);
            cancion.setNombre(nombre);
            cancion.setDuracion(duracion);
            cancion.setUrl(url);
            return practicaService.actualizarCancion(cancion);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean actualizarArtista(Integer id, String nombres, String nacionalidad) {
        try {
            Artista artista = new Artista();
            artista.setId(id);
            artista.setNombres(nombres);
            artista.setNacionidad(nacionalidad);
            return practicaService.actualizarArtista(artista);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean actualizarBanda(Integer id, String nombre) {
        try {
            Banda banda = new Banda();
            banda.setId(id);
            banda.setNombre(nombre);
            banda.setFecha(new java.util.Date());
            return practicaService.actualizarBanda(banda);
        } catch (Exception e) {
            return false;
        }
    }

    // ==============================================
    // ENDPOINTS PARA DATOS Y ESTADÍSTICAS
    // ==============================================

    public List<HashMap<String, Object>> listarCanciones() {
        return obtenerDatosOrdenados("cancion", "ninguno", "nombre");
    }

    public List<HashMap<String, Object>> listarArtistas() {
        return obtenerDatosOrdenados("artista", "ninguno", "nombre");
    }

    public List<HashMap<String, Object>> listarBandas() {
        return obtenerDatosOrdenados("banda", "ninguno", "nombre");
    }

    public HashMap<String, Object> obtenerEstadisticas() {
        HashMap<String, Object> stats = new HashMap<>();
        stats.put("totalCanciones", practicaService.contarCanciones());
        stats.put("totalArtistas", practicaService.contarArtistas());
        stats.put("totalBandas", practicaService.contarBandas());
        stats.put("resumen", practicaService.obtenerEstadisticas());
        return stats;
    }

    public boolean generarDatosAdicionales(Integer cantidad) {
        try {
            practicaService.generarDatosAdicionales(cantidad);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ==============================================
    // ENDPOINTS AUXILIARES
    // ==============================================

    public List<String> obtenerCriteriosCancion() {
        List<String> criterios = new ArrayList<>();
        criterios.add("nombre");
        criterios.add("duracion");
        criterios.add("id");
        return criterios;
    }

    public List<String> obtenerCriteriosArtista() {
        List<String> criterios = new ArrayList<>();
        criterios.add("nombre");
        criterios.add("nacionalidad");
        criterios.add("id");
        return criterios;
    }

    public List<String> obtenerCriteriosBanda() {
        List<String> criterios = new ArrayList<>();
        criterios.add("nombre");
        criterios.add("fecha");
        criterios.add("id");
        return criterios;
    }

    public List<String> obtenerAlgoritmos() {
        List<String> algoritmos = new ArrayList<>();
        algoritmos.add("quicksort");
        algoritmos.add("shellsort");
        return algoritmos;
    }
}