package org.unl.music.base.models;

public enum RolArtistaEnum {
    SOLISTA, VOCALISTA, BATERISTA, BAJISTA, GUITARRISTA;
}
