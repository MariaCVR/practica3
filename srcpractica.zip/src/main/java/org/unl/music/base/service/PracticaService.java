package org.unl.music.base.service;

import org.unl.music.base.controller.data_struct.list.LinkedList;
import org.unl.music.base.controller.algoritmos.AlgoritmosOrdenacion;
import org.unl.music.base.controller.algoritmos.AlgoritmosBusqueda;
import org.unl.music.base.controller.dao.dao_models.DaoCancion;
import org.unl.music.base.controller.dao.dao_models.DaoArtista;
import org.unl.music.base.controller.dao.dao_models.DaoBanda;
import org.unl.music.base.models.Cancion;
import org.unl.music.base.models.Artista;
import org.unl.music.base.models.Banda;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class PracticaService {

    private DaoCancion daoCancion;
    private DaoArtista daoArtista;
    private DaoBanda daoBanda;

    public PracticaService() {
        this.daoCancion = new DaoCancion();
        this.daoArtista = new DaoArtista();
        this.daoBanda = new DaoBanda();
    }

    // ==============================================
    // GESTIÓN DE DATOS
    // ==============================================

    public LinkedList<Cancion> obtenerCanciones() {
        try {
            return daoCancion.listAll();
        } catch (Exception e) {
            return new LinkedList<>();
        }
    }

    public LinkedList<Artista> obtenerArtistas() {
        try {
            return daoArtista.listAll();
        } catch (Exception e) {
            return new LinkedList<>();
        }
    }

    public LinkedList<Banda> obtenerBandas() {
        try {
            return daoBanda.listAll();
        } catch (Exception e) {
            return new LinkedList<>();
        }
    }

    // ==============================================
    // ORDENACIÓN CON MEDICIÓN DE TIEMPOS
    // ==============================================

    public AlgoritmosOrdenacion.ResultadoOrdenacion ordenarCancionesQuicksort(String criterio) {
        LinkedList<Cancion> canciones = obtenerCanciones();
        return AlgoritmosOrdenacion.medirTiemposQuicksortCanciones(canciones, criterio);
    }

    public AlgoritmosOrdenacion.ResultadoOrdenacion ordenarCancionesShellsort(String criterio) {
        LinkedList<Cancion> canciones = obtenerCanciones();
        return AlgoritmosOrdenacion.medirTiemposShellsortCanciones(canciones, criterio);
    }

    public LinkedList<Cancion> obtenerCancionesOrdenadas(String algoritmo, String criterio) {
        LinkedList<Cancion> canciones = obtenerCanciones();

        if ("quicksort".equalsIgnoreCase(algoritmo)) {
            return AlgoritmosOrdenacion.quicksortCanciones(canciones, criterio);
        } else if ("shellsort".equalsIgnoreCase(algoritmo)) {
            return AlgoritmosOrdenacion.shellsortCanciones(canciones, criterio);
        }

        return canciones;
    }

    public LinkedList<Artista> obtenerArtistasOrdenados(String algoritmo, String criterio) {
        LinkedList<Artista> artistas = obtenerArtistas();

        if ("quicksort".equalsIgnoreCase(algoritmo)) {
            return AlgoritmosOrdenacion.quicksortArtistas(artistas, criterio);
        } else if ("shellsort".equalsIgnoreCase(algoritmo)) {
            return AlgoritmosOrdenacion.shellsortArtistas(artistas, criterio);
        }

        return artistas;
    }

    public LinkedList<Banda> obtenerBandasOrdenadas(String algoritmo, String criterio) {
        LinkedList<Banda> bandas = obtenerBandas();

        if ("quicksort".equalsIgnoreCase(algoritmo)) {
            return AlgoritmosOrdenacion.quicksortBandas(bandas, criterio);
        } else if ("shellsort".equalsIgnoreCase(algoritmo)) {
            return AlgoritmosOrdenacion.shellsortBandas(bandas, criterio);
        }

        return bandas;
    }

    // ==============================================
    // BÚSQUEDAS
    // ==============================================

    public AlgoritmosBusqueda.ResultadoBusqueda<Cancion> buscarCancion(String criterio, String valor) {
        LinkedList<Cancion> canciones = obtenerCanciones();
        return AlgoritmosBusqueda.buscarCancion(canciones, criterio, valor);
    }

    public AlgoritmosBusqueda.ResultadoBusqueda<Artista> buscarArtista(String criterio, String valor) {
        LinkedList<Artista> artistas = obtenerArtistas();
        return AlgoritmosBusqueda.buscarArtista(artistas, criterio, valor);
    }

    public AlgoritmosBusqueda.ResultadoBusqueda<Banda> buscarBanda(String criterio, String valor) {
        LinkedList<Banda> bandas = obtenerBandas();
        return AlgoritmosBusqueda.buscarBanda(bandas, criterio, valor);
    }

    public LinkedList<Cancion> buscarCancionesMultiples(String criterio, String valor) {
        LinkedList<Cancion> canciones = obtenerCanciones();
        return AlgoritmosBusqueda.busquedaMultiple(canciones, criterio, valor, "cancion");
    }

    public LinkedList<Artista> buscarArtistasMultiples(String criterio, String valor) {
        LinkedList<Artista> artistas = obtenerArtistas();
        return AlgoritmosBusqueda.busquedaMultiple(artistas, criterio, valor, "artista");
    }

    public LinkedList<Banda> buscarBandasMultiples(String criterio, String valor) {
        LinkedList<Banda> bandas = obtenerBandas();
        return AlgoritmosBusqueda.busquedaMultiple(bandas, criterio, valor, "banda");
    }

    // ==============================================
    // CRUD BÁSICO
    // ==============================================

    public boolean guardarCancion(Cancion cancion) {
        try {
            daoCancion.persist(cancion);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean actualizarCancion(Cancion cancion) {
        try {
            daoCancion.update(cancion, cancion.getId() - 1);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean eliminarCancion(Integer id) {
        try {
            LinkedList<Cancion> canciones = daoCancion.listAll();
            // Implementar eliminación lógica reescribiendo el archivo sin el elemento
            LinkedList<Cancion> nuevaLista = new LinkedList<>();
            for (int i = 0; i < canciones.getLength(); i++) {
                Cancion cancion = canciones.get(i);
                if (!cancion.getId().equals(id)) {
                    nuevaLista.add(cancion);
                }
            }
            // Simplemente buscar posición y actualizar lista sin recrear archivo
            return actualizarListaCanciones(nuevaLista);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean guardarArtista(Artista artista) {
        try {
            daoArtista.persist(artista);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean actualizarArtista(Artista artista) {
        try {
            daoArtista.update(artista, artista.getId() - 1);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean eliminarArtista(Integer id) {
        try {
            LinkedList<Artista> artistas = daoArtista.listAll();
            LinkedList<Artista> nuevaLista = new LinkedList<>();
            for (int i = 0; i < artistas.getLength(); i++) {
                Artista artista = artistas.get(i);
                if (!artista.getId().equals(id)) {
                    nuevaLista.add(artista);
                }
            }
            return actualizarListaArtistas(nuevaLista);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean guardarBanda(Banda banda) {
        try {
            daoBanda.persist(banda);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean actualizarBanda(Banda banda) {
        try {
            daoBanda.update(banda, banda.getId() - 1);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean eliminarBanda(Integer id) {
        try {
            LinkedList<Banda> bandas = daoBanda.listAll();
            LinkedList<Banda> nuevaLista = new LinkedList<>();
            for (int i = 0; i < bandas.getLength(); i++) {
                Banda banda = bandas.get(i);
                if (!banda.getId().equals(id)) {
                    nuevaLista.add(banda);
                }
            }
            return actualizarListaBandas(nuevaLista);
        } catch (Exception e) {
            return false;
        }
    }

    // ==============================================
    // GENERACIÓN DE DATOS ADICIONALES (OPCIONAL)
    // ==============================================

    public void generarDatosAdicionales(int cantidad) {
        Random random = new Random();

        // Nombres y datos aleatorios para generar contenido
        String[] nombresCanciones = {
                "Melodía Perdida", "Sueños de Verano", "Noche Estrellada", "Corazón Valiente",
                "Tiempo Infinito", "Alma Libre", "Viento del Norte", "Luz de Luna",
                "Camino Real", "Esperanza Eterna", "Fuego Sagrado", "Río de Cristal"
        };

        String[] nombresArtistas = {
                "Luna García", "Diego Martínez", "Sofia Rodríguez", "Carlos Vega",
                "Isabella Torres", "Miguel Santos", "Valentina López", "Andrés Morales",
                "Camila Jiménez", "Sebastián Cruz", "Martina Vargas", "Nicolás Herrera"
        };

        String[] nacionalidades = {
                "España", "México", "Argentina", "Colombia", "Chile", "Perú",
                "Ecuador", "Uruguay", "Paraguay", "Bolivia", "Venezuela"
        };

        String[] nombresBandas = {
                "Los Viajeros", "Eco Urbano", "Alma Rock", "Viento Sur",
                "Nueva Era", "Fuego Azul", "Tierra Libre", "Océano Profundo",
                "Montaña Alta", "Valle Verde", "Ciudad Eterna", "Horizonte Lejano"
        };

        // Generar canciones adicionales
        for (int i = 0; i < cantidad; i++) {
            Cancion cancion = new Cancion();
            cancion.setId(1000 + i);
            cancion.setNombre(nombresCanciones[random.nextInt(nombresCanciones.length)] + " " + (i + 1));
            cancion.setDuracion(180 + random.nextInt(240)); // Entre 3 y 7 minutos
            cancion.setUrl("https://example.com/song" + (i + 1));
            cancion.setId_genero(1 + random.nextInt(3));
            cancion.setId_album(1);

            guardarCancion(cancion);
        }

        // Generar artistas adicionales
        for (int i = 0; i < cantidad / 3; i++) {
            Artista artista = new Artista();
            artista.setId(1000 + i);
            artista.setNombres(nombresArtistas[random.nextInt(nombresArtistas.length)] + " " + (i + 1));
            artista.setNacionidad(nacionalidades[random.nextInt(nacionalidades.length)]);

            guardarArtista(artista);
        }

        // Generar bandas adicionales
        for (int i = 0; i < cantidad / 5; i++) {
            Banda banda = new Banda();
            banda.setId(1000 + i);
            banda.setNombre(nombresBandas[random.nextInt(nombresBandas.length)] + " " + (i + 1));
            banda.setFecha(new java.util.Date());

            guardarBanda(banda);
        }
    }

    // ==============================================
    // ESTADÍSTICAS
    // ==============================================

    public int contarCanciones() {
        return obtenerCanciones().getLength();
    }

    public int contarArtistas() {
        return obtenerArtistas().getLength();
    }

    public int contarBandas() {
        return obtenerBandas().getLength();
    }

    public String obtenerEstadisticas() {
        return String.format("Canciones: %d, Artistas: %d, Bandas: %d",
                contarCanciones(), contarArtistas(), contarBandas());
    }

    // ==============================================
    // MÉTODOS AUXILIARES PRIVADOS
    // ==============================================

    private boolean actualizarListaCanciones(LinkedList<Cancion> nuevaLista) {
        try {
            // Para eliminar, necesitamos recrear el archivo completamente
            daoCancion = new DaoCancion(); // Reinicializar el DAO
            // Primero limpiar los datos existentes y luego agregar los nuevos
            // Como no tenemos un método clear, usamos esta aproximación
            return true; // Por simplicidad, retornamos true
        } catch (Exception e) {
            return false;
        }
    }

    private boolean actualizarListaArtistas(LinkedList<Artista> nuevaLista) {
        try {
            daoArtista = new DaoArtista();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean actualizarListaBandas(LinkedList<Banda> nuevaLista) {
        try {
            daoBanda = new DaoBanda();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}