package org.unl.music.base.controller.algoritmos;

import org.unl.music.base.controller.data_struct.list.LinkedList;
import org.unl.music.base.models.Cancion;
import org.unl.music.base.models.Artista;
import org.unl.music.base.models.Banda;

public class AlgoritmosBusqueda {

    // Clase para almacenar resultados de búsqueda
    public static class ResultadoBusqueda<T> {
        private T elemento;
        private int posicion;
        private boolean encontrado;
        private String metodoUsado;
        private long tiempoBusqueda;

        public ResultadoBusqueda(T elemento, int posicion, boolean encontrado, String metodoUsado, long tiempo) {
            this.elemento = elemento;
            this.posicion = posicion;
            this.encontrado = encontrado;
            this.metodoUsado = metodoUsado;
            this.tiempoBusqueda = tiempo;
        }

        // Getters
        public T getElemento() {
            return elemento;
        }

        public int getPosicion() {
            return posicion;
        }

        public boolean isEncontrado() {
            return encontrado;
        }

        public String getMetodoUsado() {
            return metodoUsado;
        }

        public long getTiempoBusqueda() {
            return tiempoBusqueda;
        }
    }

    // ==============================================
    // BÚSQUEDA INTELIGENTE - SELECTOR DE MÉTODO
    // ==============================================

    public static <T> ResultadoBusqueda<T> busquedaInteligente(LinkedList<T> lista, String criterio, String valor,
            String tipoObjeto) {
        // Si la lista está ordenada por el criterio de búsqueda, usar búsqueda binaria
        // Si no, usar búsqueda lineal
        boolean estaOrdenada = verificarOrdenamiento(lista, criterio, tipoObjeto);

        if (estaOrdenada && lista.getLength() > 10) {
            return busquedaBinaria(lista, criterio, valor, tipoObjeto);
        } else {
            return busquedaLineal(lista, criterio, valor, tipoObjeto);
        }
    }

    // ==============================================
    // BÚSQUEDA LINEAL
    // ==============================================

    public static <T> ResultadoBusqueda<T> busquedaLineal(LinkedList<T> lista, String criterio, String valor,
            String tipoObjeto) {
        long tiempoInicio = System.currentTimeMillis();

        for (int i = 0; i < lista.getLength(); i++) {
            T elemento = lista.get(i);
            String valorElemento = obtenerValorCriterio(elemento, criterio, tipoObjeto);

            if (valorElemento != null && valorElemento.toLowerCase().contains(valor.toLowerCase())) {
                long tiempoFin = System.currentTimeMillis() - tiempoInicio;
                return new ResultadoBusqueda<>(elemento, i, true, "Búsqueda Lineal", tiempoFin);
            }
        }

        long tiempoFin = System.currentTimeMillis() - tiempoInicio;
        return new ResultadoBusqueda<>(null, -1, false, "Búsqueda Lineal", tiempoFin);
    }

    // ==============================================
    // BÚSQUEDA BINARIA
    // ==============================================

    public static <T> ResultadoBusqueda<T> busquedaBinaria(LinkedList<T> lista, String criterio, String valor,
            String tipoObjeto) {
        long tiempoInicio = System.currentTimeMillis();

        T[] array = lista.toArray();
        int inicio = 0;
        int fin = array.length - 1;

        while (inicio <= fin) {
            int medio = inicio + (fin - inicio) / 2;
            T elemento = array[medio];
            String valorElemento = obtenerValorCriterio(elemento, criterio, tipoObjeto);

            if (valorElemento == null) {
                break;
            }

            int comparacion = valorElemento.toLowerCase().compareTo(valor.toLowerCase());

            if (comparacion == 0) {
                long tiempoFin = System.currentTimeMillis() - tiempoInicio;
                return new ResultadoBusqueda<>(elemento, medio, true, "Búsqueda Binaria", tiempoFin);
            } else if (comparacion < 0) {
                inicio = medio + 1;
            } else {
                fin = medio - 1;
            }
        }

        long tiempoFin = System.currentTimeMillis() - tiempoInicio;
        return new ResultadoBusqueda<>(null, -1, false, "Búsqueda Binaria", tiempoFin);
    }

    // ==============================================
    // BÚSQUEDAS ESPECÍFICAS POR TIPO
    // ==============================================

    // Búsqueda múltiple que devuelve todos los resultados que coinciden
    public static <T> LinkedList<T> busquedaMultiple(LinkedList<T> lista, String criterio, String valor,
            String tipoObjeto) {
        LinkedList<T> resultados = new LinkedList<>();

        for (int i = 0; i < lista.getLength(); i++) {
            T elemento = lista.get(i);
            String valorElemento = obtenerValorCriterio(elemento, criterio, tipoObjeto);

            if (valorElemento != null && valorElemento.toLowerCase().contains(valor.toLowerCase())) {
                resultados.add(elemento);
            }
        }

        return resultados;
    }

    // Búsqueda por canción
    public static ResultadoBusqueda<Cancion> buscarCancion(LinkedList<Cancion> lista, String criterio, String valor) {
        return busquedaInteligente(lista, criterio, valor, "cancion");
    }

    // Búsqueda por artista
    public static ResultadoBusqueda<Artista> buscarArtista(LinkedList<Artista> lista, String criterio, String valor) {
        return busquedaInteligente(lista, criterio, valor, "artista");
    }

    // Búsqueda por banda
    public static ResultadoBusqueda<Banda> buscarBanda(LinkedList<Banda> lista, String criterio, String valor) {
        return busquedaInteligente(lista, criterio, valor, "banda");
    }

    // ==============================================
    // MÉTODOS AUXILIARES
    // ==============================================

    private static <T> String obtenerValorCriterio(T elemento, String criterio, String tipoObjeto) {
        try {
            switch (tipoObjeto.toLowerCase()) {
                case "cancion":
                    Cancion cancion = (Cancion) elemento;
                    switch (criterio.toLowerCase()) {
                        case "nombre":
                            return cancion.getNombre();
                        case "duracion":
                            return cancion.getDuracion().toString();
                        case "id":
                            return cancion.getId().toString();
                        default:
                            return cancion.getNombre();
                    }

                case "artista":
                    Artista artista = (Artista) elemento;
                    switch (criterio.toLowerCase()) {
                        case "nombre":
                            return artista.getNombres();
                        case "nacionalidad":
                            return artista.getNacionidad();
                        case "id":
                            return artista.getId().toString();
                        default:
                            return artista.getNombres();
                    }

                case "banda":
                    Banda banda = (Banda) elemento;
                    switch (criterio.toLowerCase()) {
                        case "nombre":
                            return banda.getNombre();
                        case "fecha":
                            return banda.getFecha().toString();
                        case "id":
                            return banda.getId().toString();
                        default:
                            return banda.getNombre();
                    }

                default:
                    return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static <T> boolean verificarOrdenamiento(LinkedList<T> lista, String criterio, String tipoObjeto) {
        if (lista.getLength() < 2)
            return true;

        for (int i = 0; i < lista.getLength() - 1; i++) {
            T actual = lista.get(i);
            T siguiente = lista.get(i + 1);

            String valorActual = obtenerValorCriterio(actual, criterio, tipoObjeto);
            String valorSiguiente = obtenerValorCriterio(siguiente, criterio, tipoObjeto);

            if (valorActual == null || valorSiguiente == null) {
                return false;
            }

            if (valorActual.compareToIgnoreCase(valorSiguiente) > 0) {
                return false;
            }
        }

        return true;
    }

    // ==============================================
    // BÚSQUEDAS AVANZADAS
    // ==============================================

    // Búsqueda por rango (útil para duraciones, fechas, etc.)
    public static <T> LinkedList<T> busquedaPorRango(LinkedList<T> lista, String criterio, String valorMin,
            String valorMax, String tipoObjeto) {
        LinkedList<T> resultados = new LinkedList<>();

        for (int i = 0; i < lista.getLength(); i++) {
            T elemento = lista.get(i);
            String valorElemento = obtenerValorCriterio(elemento, criterio, tipoObjeto);

            if (valorElemento != null) {
                if (valorElemento.compareToIgnoreCase(valorMin) >= 0 &&
                        valorElemento.compareToIgnoreCase(valorMax) <= 0) {
                    resultados.add(elemento);
                }
            }
        }

        return resultados;
    }

    // Búsqueda aproximada (Fuzzy search)
    public static <T> LinkedList<T> busquedaAproximada(LinkedList<T> lista, String criterio, String valor,
            String tipoObjeto, double umbralSimilitud) {
        LinkedList<T> resultados = new LinkedList<>();

        for (int i = 0; i < lista.getLength(); i++) {
            T elemento = lista.get(i);
            String valorElemento = obtenerValorCriterio(elemento, criterio, tipoObjeto);

            if (valorElemento != null) {
                double similitud = calcularSimilitud(valorElemento.toLowerCase(), valor.toLowerCase());
                if (similitud >= umbralSimilitud) {
                    resultados.add(elemento);
                }
            }
        }

        return resultados;
    }

    // Calcula la similitud entre dos strings usando distancia de Levenshtein
    // normalizada
    private static double calcularSimilitud(String s1, String s2) {
        int distancia = distanciaLevenshtein(s1, s2);
        int maxLength = Math.max(s1.length(), s2.length());
        return maxLength == 0 ? 1.0 : 1.0 - (double) distancia / maxLength;
    }

    // Algoritmo de distancia de Levenshtein
    private static int distanciaLevenshtein(String s1, String s2) {
        int[][] dp = new int[s1.length() + 1][s2.length() + 1];

        for (int i = 0; i <= s1.length(); i++) {
            dp[i][0] = i;
        }

        for (int j = 0; j <= s2.length(); j++) {
            dp[0][j] = j;
        }

        for (int i = 1; i <= s1.length(); i++) {
            for (int j = 1; j <= s2.length(); j++) {
                if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(Math.min(dp[i - 1][j], dp[i][j - 1]), dp[i - 1][j - 1]);
                }
            }
        }

        return dp[s1.length()][s2.length()];
    }
}